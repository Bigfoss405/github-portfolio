package com.example.eventbuddy;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.example.eventbuddy.data.DBHelper;
import com.example.eventbuddy.data.Event;

import java.util.List;
import java.util.Locale;

public class DataGridActivity extends AppCompatActivity implements EventAdapter.OnEditClickListener {

    private RecyclerView dataRecyclerView;
    private FloatingActionButton addButton, smsButton;
    private EventAdapter adapter;
    private DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        db = new DBHelper(this);

        dataRecyclerView = findViewById(R.id.dataRecyclerView);
        addButton = findViewById(R.id.addButton);
        smsButton = findViewById(R.id.smsButton);

        dataRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        EventAdapter.OnItemClickListener onItemClickListener = event -> {
            // Handle item click if needed, e.g., open event details
        };

        EventAdapter.OnDeleteClickListener onDeleteClickListener = (event, position) -> {
            db.deleteEvent(event.id);
            refreshEventList();
        };

        // Pass 'this' as the OnEditClickListener
        adapter = new EventAdapter(onItemClickListener, onDeleteClickListener, this);
        dataRecyclerView.setAdapter(adapter);

        refreshEventList(); // Initial load

        addButton.setOnClickListener(v -> showAddEventDialog());

        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataGridActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public void onEditClick(Event event) {
        showEditEventDialog(event);
    }

    private void showAddEventDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        android.view.View view = inflater.inflate(R.layout.dialog_event, null);

        EditText etTitle = view.findViewById(R.id.etTitle);
        EditText etDate = view.findViewById(R.id.etDate); // expect YYYY-MM-DD
        EditText etLocation = view.findViewById(R.id.etLocation);
        EditText etNotes = view.findViewById(R.id.etNotes);
        EditText etAttendees = view.findViewById(R.id.etAttendees);

        new AlertDialog.Builder(this)
                .setTitle("Add Event")
                .setView(view)
                .setPositiveButton("Save", (d, which) -> {
                    String title = etTitle.getText().toString().trim();
                    String date = etDate.getText().toString().trim();
                    String loc = etLocation.getText().toString().trim();
                    String notes = etNotes.getText().toString().trim();
                    String attS = etAttendees.getText().toString().trim();

                    if (title.isEmpty() || date.isEmpty()) {
                        // minimal guard; you can toast here if you want
                        return;
                    }

                    Event e = new Event();
                    e.title = title;
                    e.dateIso = date;
                    e.location = loc.isEmpty() ? null : loc;
                    e.notes = notes.isEmpty() ? null : notes;
                    e.attendees = attS.isEmpty() ? 0 : Integer.parseInt(attS);

                    long id = db.insertEvent(e);
                    if (id > 0) {
                        refreshEventList();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditEventDialog(Event eventToEdit) {
        LayoutInflater inflater = LayoutInflater.from(this);
        android.view.View view = inflater.inflate(R.layout.dialog_event, null);

        EditText etTitle = view.findViewById(R.id.etTitle);
        EditText etDate = view.findViewById(R.id.etDate);
        EditText etLocation = view.findViewById(R.id.etLocation);
        EditText etNotes = view.findViewById(R.id.etNotes);
        EditText etAttendees = view.findViewById(R.id.etAttendees);

        // Pre-fill dialog with existing event data
        etTitle.setText(eventToEdit.title);
        etDate.setText(eventToEdit.dateIso);
        etLocation.setText(eventToEdit.location);
        etNotes.setText(eventToEdit.notes);
        etAttendees.setText(String.format(Locale.getDefault(), "%d", eventToEdit.attendees));

        new AlertDialog.Builder(this)
                .setTitle("Edit Event")
                .setView(view)
                .setPositiveButton("Save", (d, which) -> {
                    String title = etTitle.getText().toString().trim();
                    String date = etDate.getText().toString().trim();
                    String loc = etLocation.getText().toString().trim();
                    String notes = etNotes.getText().toString().trim();
                    String attS = etAttendees.getText().toString().trim();

                    if (title.isEmpty() || date.isEmpty()) {
                        // minimal guard; you can toast here if you want
                        return;
                    }

                    // Create a new event object or update the existing one
                    Event updatedEvent = new Event();
                    updatedEvent.id = eventToEdit.id; // IMPORTANT: Keep the original ID
                    updatedEvent.title = title;
                    updatedEvent.dateIso = date;
                    updatedEvent.location = loc.isEmpty() ? null : loc;
                    updatedEvent.notes = notes.isEmpty() ? null : notes;
                    updatedEvent.attendees = attS.isEmpty() ? 0 : Integer.parseInt(attS);

                    int rowsAffected = db.updateEvent(updatedEvent); // This method needs to be created in DBHelper
                    if (rowsAffected > 0) {
                        refreshEventList();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshEventList() {
        List<Event> events = db.getAllEvents();
        adapter.submitList(events);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshEventList();
    }
}
