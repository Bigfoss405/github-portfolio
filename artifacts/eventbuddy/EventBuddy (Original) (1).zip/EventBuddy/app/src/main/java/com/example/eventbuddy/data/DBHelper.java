package com.example.eventbuddy.data;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "eventbuddy.db";
    private static final int DB_VERSION = 1;

    // Table & columns
    public static final String T_EVENTS   = "events";
    public static final String C_ID       = "_id";
    public static final String C_TITLE    = "title";
    public static final String C_DATE     = "date_iso";
    public static final String C_LOCATION = "location";
    public static final String C_NOTES    = "notes";
    public static final String C_ATTEN    = "attendees";

    public DBHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + T_EVENTS + " (" +
                        C_ID       + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        C_TITLE    + " TEXT NOT NULL, " +
                        C_DATE     + " TEXT NOT NULL, " +      // store as "YYYY-MM-DD"
                        C_LOCATION + " TEXT, " +
                        C_NOTES    + " TEXT, " +
                        C_ATTEN    + " INTEGER DEFAULT 0" +
                        ")"
        );
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + T_EVENTS);
        onCreate(db);
    }

    // CREATE
    public long insertEvent(Event e) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_TITLE,    e.title);
        cv.put(C_DATE,     e.dateIso);
        cv.put(C_LOCATION, e.location);
        cv.put(C_NOTES,    e.notes);
        cv.put(C_ATTEN,    e.attendees);
        return db.insert(T_EVENTS, null, cv);
    }

    // READ (all)
    public List<Event> getAllEvents() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_EVENTS, null, null, null, null, null, C_DATE + " ASC");
        List<Event> out = new ArrayList<>();
        try {
            int iId   = c.getColumnIndexOrThrow(C_ID);
            int iT    = c.getColumnIndexOrThrow(C_TITLE);
            int iD    = c.getColumnIndexOrThrow(C_DATE);
            int iLoc  = c.getColumnIndexOrThrow(C_LOCATION);
            int iN    = c.getColumnIndexOrThrow(C_NOTES);
            int iAtt  = c.getColumnIndexOrThrow(C_ATTEN);
            while (c.moveToNext()) {
                Event e = new Event();
                e.id         = c.getLong(iId);
                e.title      = c.getString(iT);
                e.dateIso    = c.getString(iD);
                e.location   = c.isNull(iLoc) ? null : c.getString(iLoc);
                e.notes      = c.isNull(iN)   ? null : c.getString(iN);
                e.attendees  = c.getInt(iAtt);
                out.add(e);
            }
        } finally {
            c.close();
        }
        return out;
    }

    // UPDATE
    public int updateEvent(Event e) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(C_TITLE,    e.title);
        cv.put(C_DATE,     e.dateIso);
        cv.put(C_LOCATION, e.location);
        cv.put(C_NOTES,    e.notes);
        cv.put(C_ATTEN,    e.attendees);
        return db.update(T_EVENTS, cv, C_ID + "=?", new String[]{ String.valueOf(e.id) });
    }

    // DELETE
    public int deleteEvent(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(T_EVENTS, C_ID + "=?", new String[]{ String.valueOf(id) });
    }
}
