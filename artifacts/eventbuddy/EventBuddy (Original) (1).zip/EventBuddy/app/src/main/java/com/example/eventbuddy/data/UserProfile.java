package com.example.eventbuddy.data;

public class UserProfile {
    public long uid; // always 1
    public String displayName;
    public String email;
    public Integer defaultReminderMinutes;

    public UserProfile(long uid, String displayName, String email, Integer defaultReminderMinutes) {
        this.uid = uid;
        this.displayName = displayName;
        this.email = email;
        this.defaultReminderMinutes = defaultReminderMinutes;
    }
}
