package com.example.eventbuddy.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.example.eventbuddy.R;
import com.example.eventbuddy.data.DBHelper;
import com.example.eventbuddy.data.Event;
import com.example.eventbuddy.databinding.ActivityMainBinding;
import com.example.eventbuddy.EventAdapter; // Added import
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DBHelper db;
    private EventAdapter adapter;
    private ActivityMainBinding b; // Kept as a field for now, can be localized if not used elsewhere

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        b = ActivityMainBinding.inflate(getLayoutInflater()); // Made b local
        setContentView(b.getRoot());

        db = new DBHelper(this);

        // Updated adapter instantiation
        adapter = new EventAdapter(
                this::showEditDialog, // OnItemClickListener - for clicking the whole item
                (event, position) -> { // OnDeleteClickListener
                    db.deleteEvent(event.id);
                    refresh();
                },
                this::showEditDialog // OnEditClickListener - for clicking the dedicated edit button
        );
        b.recycler.setLayoutManager(new GridLayoutManager(this, 2)); // GRID columns
        b.recycler.setAdapter(adapter);

        refresh();

        b.fabAdd.setOnClickListener(v -> showAddDialog());

        // Swipe to delete
        ItemTouchHelper ith = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override public boolean onMove(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder vh, @NonNull RecyclerView.ViewHolder t) { return false; } // Added @NonNull
            @Override public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int dir) { // Added @NonNull
                Event e = adapter.getItem(vh.getBindingAdapterPosition());
                if (e != null) { // getItem can return null if position is out of bounds
                    db.deleteEvent(e.id);
                    refresh();
                }
            }
        });
        ith.attachToRecyclerView(b.recycler);
    }

    private void refresh() {
        List<Event> events = db.getAllEvents();
        adapter.submitList(events);
    }

    private void showAddDialog() {
        LayoutInflater inf = LayoutInflater.from(this);
        android.view.View v = inf.inflate(R.layout.dialog_event, null);
        EditText etTitle = v.findViewById(R.id.etTitle);
        EditText etDate = v.findViewById(R.id.etDate);
        EditText etLocation = v.findViewById(R.id.etLocation);
        EditText etNotes = v.findViewById(R.id.etNotes);
        EditText etAttendees = v.findViewById(R.id.etAttendees);

        new MaterialAlertDialogBuilder(this)
                .setTitle("Add event")
                .setView(v)
                .setPositiveButton("Save", (d, which) -> {
                    String title = etTitle.getText().toString().trim();
                    String date = etDate.getText().toString().trim();
                    String loc = emptyToNull(etLocation.getText().toString());
                    String notes = emptyToNull(etNotes.getText().toString());
                    int attendees = parseIntOrZero(etAttendees.getText().toString());
                    if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(date)) {
                        Event newEvent = new Event();
                        newEvent.title = title;
                        newEvent.dateIso = date;
                        newEvent.location = loc;
                        newEvent.notes = notes;
                        newEvent.attendees = attendees;
                        db.insertEvent(newEvent);
                        refresh();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditDialog(Event e) {
        LayoutInflater inf = LayoutInflater.from(this);
        android.view.View v = inf.inflate(R.layout.dialog_event, null);
        EditText etTitle = v.findViewById(R.id.etTitle);      etTitle.setText(e.title);
        EditText etDate = v.findViewById(R.id.etDate);        etDate.setText(e.dateIso);
        EditText etLocation = v.findViewById(R.id.etLocation);etLocation.setText(e.location == null ? "" : e.location);
        EditText etNotes = v.findViewById(R.id.etNotes);      etNotes.setText(e.notes == null ? "" : e.notes);
        EditText etAttendees = v.findViewById(R.id.etAttendees); etAttendees.setText(String.valueOf(e.attendees));

        new MaterialAlertDialogBuilder(this)
                .setTitle("Edit event")
                .setView(v)
                .setPositiveButton("Update", (d, which) -> {
                    e.title = etTitle.getText().toString().trim();
                    e.dateIso = etDate.getText().toString().trim();
                    e.location = emptyToNull(etLocation.getText().toString());
                    e.notes = emptyToNull(etNotes.getText().toString());
                    e.attendees = parseIntOrZero(etAttendees.getText().toString());
                    db.updateEvent(e);
                    refresh();
                })
                .setNeutralButton("Delete", (d, which) -> {
                    db.deleteEvent(e.id);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private static int parseIntOrZero(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }
    private static String emptyToNull(String s) {
        String t = s == null ? null : s.trim();
        return (t == null || t.isEmpty()) ? null : t;
    }
}
