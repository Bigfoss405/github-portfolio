package com.example.eventbuddy;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eventbuddy.data.Event;
import com.example.eventbuddy.data.EventRepository;
import com.example.eventbuddy.data.EventValidator;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DataGridActivity extends AppCompatActivity implements EventAdapter.OnEditClickListener {

    private RecyclerView dataRecyclerView;
    private FloatingActionButton addButton, smsButton;
    private EventAdapter adapter;
    private EventRepository eventRepository;

    // Search UI
    private EditText searchInput;
    private ImageButton searchButton;
    private ImageButton clearSearchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        eventRepository = new EventRepository(this);

        dataRecyclerView = findViewById(R.id.dataRecyclerView);
        addButton = findViewById(R.id.addButton);
        smsButton = findViewById(R.id.smsButton);

        searchInput = findViewById(R.id.searchInput);
        searchButton = findViewById(R.id.searchButton);
        clearSearchButton = findViewById(R.id.clearSearchButton);

        dataRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        EventAdapter.OnItemClickListener onItemClickListener = event -> {
            // Optional: show details screen here
        };

        EventAdapter.OnDeleteClickListener onDeleteClickListener = (event, position) -> {
            eventRepository.deleteEvent(event.id);
            refreshEventList();
        };

        adapter = new EventAdapter(onItemClickListener, onDeleteClickListener, this);
        dataRecyclerView.setAdapter(adapter);

        // Optionally seed demo data using a single transaction
        seedIfEmpty();

        // Initial load
        refreshEventList();

        addButton.setOnClickListener(v -> showAddEventDialog());

        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataGridActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });

        // Search button: filter by title
        searchButton.setOnClickListener(v -> {
            String keyword = searchInput.getText().toString().trim();
            if (keyword.isEmpty()) {
                refreshEventList();
            } else {
                List<Event> results = eventRepository.searchEventsByTitle(keyword);
                adapter.submitList(results);
            }
        });

        // Clear button: clear text and reload all events
        clearSearchButton.setOnClickListener(v -> {
            searchInput.setText("");
            refreshEventList();
        });
    }

    @Override
    public void onEditClick(Event event) {
        showEditEventDialog(event);
    }

    private void showAddEventDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.dialog_event, null);

        EditText etTitle = view.findViewById(R.id.etTitle);
        EditText etDate = view.findViewById(R.id.etDate); // expect YYYY-MM-DD
        EditText etLocation = view.findViewById(R.id.etLocation);
        EditText etNotes = view.findViewById(R.id.etNotes);
        EditText etAttendees = view.findViewById(R.id.etAttendees);

        new AlertDialog.Builder(this)
                .setTitle("Add Event")
                .setView(view)
                .setPositiveButton("Save", (d, which) -> {
                    String title = etTitle.getText().toString().trim();
                    String date = etDate.getText().toString().trim();
                    String loc = etLocation.getText().toString().trim();
                    String notes = etNotes.getText().toString().trim();
                    String attS = etAttendees.getText().toString().trim();

                    // Validation with user feedback
                    boolean hasError = false;

                    if (!EventValidator.isValidTitle(title)) {
                        etTitle.setError("Title is required");
                        hasError = true;
                    }

                    if (!EventValidator.isValidDate(date)) {
                        etDate.setError("Use format YYYY-MM-DD");
                        hasError = true;
                    }

                    if (!attS.isEmpty() && !EventValidator.isValidAttendees(attS)) {
                        etAttendees.setError("Attendees must be a whole number");
                        hasError = true;
                    }

                    if (hasError) {
                        Toast.makeText(this, "Please fix the errors before saving", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Event e = new Event();
                    e.title = title;
                    e.dateIso = date;
                    e.location = loc.isEmpty() ? null : loc;
                    e.notes = notes.isEmpty() ? null : notes;

                    try {
                        e.attendees = attS.isEmpty() ? 0 : Integer.parseInt(attS);
                    } catch (NumberFormatException ex) {
                        e.attendees = 0;
                    }

                    long id = eventRepository.insertEvent(e);
                    if (id > 0) {
                        refreshEventList();
                        Toast.makeText(this, "Event added", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error saving event", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditEventDialog(Event eventToEdit) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.dialog_event, null);

        EditText etTitle = view.findViewById(R.id.etTitle);
        EditText etDate = view.findViewById(R.id.etDate);
        EditText etLocation = view.findViewById(R.id.etLocation);
        EditText etNotes = view.findViewById(R.id.etNotes);
        EditText etAttendees = view.findViewById(R.id.etAttendees);

        etTitle.setText(eventToEdit.title);
        etDate.setText(eventToEdit.dateIso);
        etLocation.setText(eventToEdit.location);
        etNotes.setText(eventToEdit.notes);
        etAttendees.setText(String.format(Locale.getDefault(), "%d", eventToEdit.attendees));

        new AlertDialog.Builder(this)
                .setTitle("Edit Event")
                .setView(view)
                .setPositiveButton("Save", (d, which) -> {
                    String title = etTitle.getText().toString().trim();
                    String date = etDate.getText().toString().trim();
                    String loc = etLocation.getText().toString().trim();
                    String notes = etNotes.getText().toString().trim();
                    String attS = etAttendees.getText().toString().trim();

                    boolean hasError = false;

                    if (!EventValidator.isValidTitle(title)) {
                        etTitle.setError("Title is required");
                        hasError = true;
                    }

                    if (!EventValidator.isValidDate(date)) {
                        etDate.setError("Use format YYYY-MM-DD");
                        hasError = true;
                    }

                    if (!attS.isEmpty() && !EventValidator.isValidAttendees(attS)) {
                        etAttendees.setError("Attendees must be a whole number");
                        hasError = true;
                    }

                    if (hasError) {
                        Toast.makeText(this, "Please fix the errors before saving", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Event updatedEvent = new Event();
                    updatedEvent.id = eventToEdit.id;
                    updatedEvent.title = title;
                    updatedEvent.dateIso = date;
                    updatedEvent.location = loc.isEmpty() ? null : loc;
                    updatedEvent.notes = notes.isEmpty() ? null : notes;

                    try {
                        updatedEvent.attendees = attS.isEmpty() ? 0 : Integer.parseInt(attS);
                    } catch (NumberFormatException ex) {
                        updatedEvent.attendees = 0;
                    }

                    int rowsAffected = eventRepository.updateEvent(updatedEvent);
                    if (rowsAffected > 0) {
                        refreshEventList();
                        Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error updating event", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshEventList() {
        List<Event> events = eventRepository.getAllEvents();
        adapter.submitList(events);
    }


    private void seedIfEmpty() {
        List<Event> current = eventRepository.getAllEvents();
        if (!current.isEmpty()) {
            return;
        }

        List<Event> demoEvents = new ArrayList<>();

        Event e1 = new Event();
        e1.title = "Project Kickoff";
        e1.dateIso = "2025-01-10";
        e1.location = "Office";
        e1.notes = "Initial planning meeting";
        e1.attendees = 5;
        demoEvents.add(e1);

        Event e2 = new Event();
        e2.title = "Family Birthday";
        e2.dateIso = "2025-02-03";
        e2.location = "Home";
        e2.notes = "Order cake and balloons";
        e2.attendees = 10;
        demoEvents.add(e2);

        Event e3 = new Event();
        e3.title = "Doctor Appointment";
        e3.dateIso = "2025-03-15";
        e3.location = "Clinic";
        e3.notes = "Bring insurance card";
        e3.attendees = 1;
        demoEvents.add(e3);

        // This call uses a single transaction under the hood
        eventRepository.insertEvents(demoEvents);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshEventList();
    }
}
