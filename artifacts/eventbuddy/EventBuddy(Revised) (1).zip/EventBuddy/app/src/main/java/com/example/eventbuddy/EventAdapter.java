package com.example.eventbuddy;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eventbuddy.data.Event;

import java.util.Objects;

public class EventAdapter extends ListAdapter<Event, EventAdapter.EventViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(Event event);
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(Event event, int position);
    }

    public interface OnEditClickListener { // New interface
        void onEditClick(Event event);
    }

    private final OnItemClickListener onItemClickListener;
    private final OnDeleteClickListener onDeleteClickListener;
    private final OnEditClickListener onEditClickListener; // New listener field

    public EventAdapter(@NonNull OnItemClickListener onItemClickListener,
                        @NonNull OnDeleteClickListener onDeleteClickListener,
                        @NonNull OnEditClickListener onEditClickListener) { // Updated constructor
        super(DIFF_CALLBACK);
        this.onItemClickListener = onItemClickListener;
        this.onDeleteClickListener = onDeleteClickListener;
        this.onEditClickListener = onEditClickListener; // Assign new listener
    }

    // Add public getItem method
    public Event getItem(int position) {
        return super.getItem(position);
    }

    private static final DiffUtil.ItemCallback<Event> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<Event>() {
                @Override
                public boolean areItemsTheSame(@NonNull Event oldItem, @NonNull Event newItem) {
                    return oldItem.getId() == newItem.getId();
                }

                @Override
                public boolean areContentsTheSame(@NonNull Event oldItem, @NonNull Event newItem) {
                    // Compare all fields that affect UI
                    return Objects.equals(oldItem.getTitle(), newItem.getTitle()) &&
                           Objects.equals(oldItem.getDateIso(), newItem.getDateIso()) &&
                           Objects.equals(oldItem.getLocation(), newItem.getLocation()) &&
                           oldItem.getAttendees() == newItem.getAttendees() &&
                           Objects.equals(oldItem.getNotes(), newItem.getNotes()); // Assuming notes might be displayed or used
                }
            };

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder h, int position) {
        Event e = getItem(position); // Now calls the public getItem

        if (e == null) {
            h.title.setText("Invalid Event");
            h.date.setText("");
            h.location.setText("");
            h.attendees.setText("");
            h.deleteButton.setVisibility(View.GONE);
            h.editButton.setVisibility(View.GONE); // Hide edit button
            return;
        }

        h.title.setText(nullOrEmpty(e.getTitle()) ? "Untitled" : e.getTitle());
        h.date.setText(nullOrEmpty(e.getDateIso()) ? "No date" : e.getDateIso());
        h.location.setText(nullOrEmpty(e.getLocation()) ? "No location" : e.getLocation());
        h.attendees.setText("Attendees: " + e.getAttendees());
        h.deleteButton.setVisibility(View.VISIBLE);
        h.editButton.setVisibility(View.VISIBLE); // Show edit button

        h.itemView.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(e);
            }
        });

        h.editButton.setOnClickListener(v -> { // Set listener for edit button
            if (onEditClickListener != null) {
                onEditClickListener.onEditClick(e);
            }
        });

        h.deleteButton.setOnClickListener(v -> {
            if (onDeleteClickListener != null) {
                onDeleteClickListener.onDeleteClick(e, h.getBindingAdapterPosition());
            }
        });
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView title, date, location, attendees;
        ImageButton deleteButton, editButton; // Added editButton

        EventViewHolder(@NonNull View itemView) {
            super(itemView);
            title        = itemView.findViewById(R.id.eventTitle);
            date         = itemView.findViewById(R.id.eventDate);
            location     = itemView.findViewById(R.id.eventLocation);
            attendees    = itemView.findViewById(R.id.eventAttendees);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            editButton   = itemView.findViewById(R.id.editButton); // Find new button
        }
    }

    private static boolean nullOrEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }
}
