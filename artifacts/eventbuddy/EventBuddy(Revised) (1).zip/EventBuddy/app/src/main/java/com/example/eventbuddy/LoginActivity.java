package com.example.eventbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText usernameField, passwordField;
    private MaterialButton loginButton, createAccountButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI components
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Handle login button
        loginButton.setOnClickListener(v -> handleAuth(false));

        // Handle create account button
        createAccountButton.setOnClickListener(v -> handleAuth(true));
    }

    private void handleAuth(boolean isCreateAccount) {
        String username = usernameField.getText() != null ? usernameField.getText().toString().trim() : "";
        String password = passwordField.getText() != null ? passwordField.getText().toString().trim() : "";

        // Validate fields
        if (username.isEmpty() || password.isEmpty()) {
            if (username.isEmpty()) usernameField.setError("Required");
            if (password.isEmpty()) passwordField.setError("Required");
            return;
        }

        // Placeholder feedback
        String message = isCreateAccount ? "Account created (placeholder)" : "Login successful (placeholder)";
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

        // Navigate to Data Grid Activity
        Intent intent = new Intent(LoginActivity.this, DataGridActivity.class);
        startActivity(intent);
    }
}
