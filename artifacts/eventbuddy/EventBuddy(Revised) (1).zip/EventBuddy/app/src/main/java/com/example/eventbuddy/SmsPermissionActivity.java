package com.example.eventbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class SmsPermissionActivity extends AppCompatActivity {

    private MaterialButton grantPermissionButton;
    private MaterialButton declinePermissionButton;
    private TextView permissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // Initialize UI elements
        grantPermissionButton = findViewById(R.id.grantSmsPermissionButton);
        declinePermissionButton = findViewById(R.id.declineSmsPermissionButton);
        permissionStatus = findViewById(R.id.permissionStatus);

        // Handle Grant Permission button
        grantPermissionButton.setOnClickListener(v -> {
            // Update status text (placeholder for real permission logic)
            permissionStatus.setText(R.string.sms_permission_granted);

            // Navigate back to DataGridActivity
            Intent intent = new Intent(SmsPermissionActivity.this, DataGridActivity.class);
            startActivity(intent);
            finish();
        });

        // Handle Decline Permission button
        declinePermissionButton.setOnClickListener(v -> {
            // Update status text
            permissionStatus.setText(R.string.sms_permission_declined);

            // Navigate back to DataGridActivity
            Intent intent = new Intent(SmsPermissionActivity.this, DataGridActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
