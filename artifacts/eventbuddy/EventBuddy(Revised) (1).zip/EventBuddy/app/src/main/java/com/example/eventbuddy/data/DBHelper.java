package com.example.eventbuddy.data;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "eventbuddy.db";
    // Schema version 2 with indexes, foreign key support, and transaction handling
    private static final int DB_VERSION = 2;

    // Table and columns
    public static final String T_EVENTS   = "events";
    public static final String C_ID       = "_id";
    public static final String C_TITLE    = "title";
    public static final String C_DATE     = "date_iso";
    public static final String C_LOCATION = "location";
    public static final String C_NOTES    = "notes";
    public static final String C_ATTEN    = "attendees";

    public DBHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Ensure SQLite enforces foreign key constraints for future related tables
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Base events table
        db.execSQL(
                "CREATE TABLE " + T_EVENTS + " (" +
                        C_ID       + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        C_TITLE    + " TEXT NOT NULL, " +
                        C_DATE     + " TEXT NOT NULL, " +      // store as "YYYY-MM-DD"
                        C_LOCATION + " TEXT, " +
                        C_NOTES    + " TEXT, " +
                        C_ATTEN    + " INTEGER DEFAULT 0" +
                        ")"
        );

        // Indexes for faster lookups and ordering
        db.execSQL(
                "CREATE INDEX IF NOT EXISTS idx_events_date " +
                        "ON " + T_EVENTS + " (" + C_DATE + ")"
        );
        db.execSQL(
                "CREATE INDEX IF NOT EXISTS idx_events_title " +
                        "ON " + T_EVENTS + " (" + C_TITLE + ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // Simple strategy for this project: drop and recreate schema version 2
        db.execSQL("DROP INDEX IF EXISTS idx_events_date");
        db.execSQL("DROP INDEX IF EXISTS idx_events_title");
        db.execSQL("DROP TABLE IF EXISTS " + T_EVENTS);
        onCreate(db);
    }

    // Helper that builds ContentValues from an Event
    private ContentValues toContentValues(Event e) {
        ContentValues cv = new ContentValues();
        cv.put(C_TITLE,    e.title);
        cv.put(C_DATE,     e.dateIso);
        cv.put(C_LOCATION, e.location);
        cv.put(C_NOTES,    e.notes);
        // Ensure attendees is not negative
        cv.put(C_ATTEN,    Math.max(0, e.attendees));
        return cv;
    }

    // Helper that turns a Cursor into a list of Event objects
    private List<Event> readEventsFromCursor(Cursor c) {
        List<Event> out = new ArrayList<>();
        if (c == null) {
            return out;
        }

        int iId   = c.getColumnIndexOrThrow(C_ID);
        int iT    = c.getColumnIndexOrThrow(C_TITLE);
        int iD    = c.getColumnIndexOrThrow(C_DATE);
        int iLoc  = c.getColumnIndexOrThrow(C_LOCATION);
        int iN    = c.getColumnIndexOrThrow(C_NOTES);
        int iAtt  = c.getColumnIndexOrThrow(C_ATTEN);

        while (c.moveToNext()) {
            Event e = new Event();
            e.id        = c.getLong(iId);
            e.title     = c.getString(iT);
            e.dateIso   = c.getString(iD);
            e.location  = c.isNull(iLoc) ? null : c.getString(iLoc);
            e.notes     = c.isNull(iN)   ? null : c.getString(iN);
            e.attendees = c.getInt(iAtt);
            out.add(e);
        }
        return out;
    }

    // CREATE
    public long insertEvent(Event e) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = toContentValues(e);
        return db.insert(T_EVENTS, null, cv);
    }

    // READ all events ordered by date ascending
    public List<Event> getAllEvents() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                T_EVENTS,
                null,
                null,
                null,
                null,
                null,
                C_DATE + " ASC"
        );
        try {
            return readEventsFromCursor(c);
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

    // READ events on a specific date
    public List<Event> getEventsOnDate(String dateIso) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                T_EVENTS,
                null,
                C_DATE + " = ?",
                new String[]{ dateIso },
                null,
                null,
                C_TITLE + " ASC"
        );
        try {
            return readEventsFromCursor(c);
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

    // READ events between two dates inclusive
    public List<Event> getEventsInRange(String startDateIso, String endDateIso) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                T_EVENTS,
                null,
                C_DATE + " >= ? AND " + C_DATE + " <= ?",
                new String[]{ startDateIso, endDateIso },
                null,
                null,
                C_DATE + " ASC"
        );
        try {
            return readEventsFromCursor(c);
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

    // READ events whose title contains a keyword
    public List<Event> searchEventsByTitle(String keyword) {
        SQLiteDatabase db = getReadableDatabase();
        String like = "%" + keyword + "%";

        Cursor c = db.query(
                T_EVENTS,
                null,
                C_TITLE + " LIKE ?",
                new String[]{ like },
                null,
                null,
                C_DATE + " ASC"
        );

        try {
            return readEventsFromCursor(c);
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

    // UPDATE
    public int updateEvent(Event e) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = toContentValues(e);
        return db.update(
                T_EVENTS,
                cv,
                C_ID + "=?",
                new String[]{ String.valueOf(e.id) }
        );
    }

    // DELETE
    public int deleteEvent(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(
                T_EVENTS,
                C_ID + "=?",
                new String[]{ String.valueOf(id) }
        );
    }

    // BULK CREATE with explicit transaction for many events
    public void insertEvents(List<Event> events) {
        if (events == null || events.isEmpty()) {
            return;
        }

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (Event e : events) {
                if (e == null) continue;
                ContentValues cv = toContentValues(e);
                db.insert(T_EVENTS, null, cv);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}
