package com.example.eventbuddy.data;

public class Event {
    public long id;          // DB primary key
    public String title;
    public String dateIso;   // "YYYY-MM-DD"
    public String location;
    public String notes;
    public int attendees;

    public Event() { }

    // Used by DataGridActivity sample data and the card adapter
    public Event(String title, String dateIso) {
        this(0L, title, dateIso, null, null, 0);
    }

    // For creating before DB id is known
    public Event(String title, String dateIso, String location, String notes, int attendees) {
        this(0L, title, dateIso, location, notes, attendees);
    }

    // Full constructor (used by DB reads)
    public Event(long id, String title, String dateIso, String location, String notes, int attendees) {
        this.id = id;
        this.title = title;
        this.dateIso = dateIso;
        this.location = location;
        this.notes = notes;
        this.attendees = attendees;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    // Alias so adapters calling getDate() work
    public String getDate() { return dateIso; }

    public String getDateIso() { return dateIso; }
    public void setDateIso(String dateIso) { this.dateIso = dateIso; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public int getAttendees() { return attendees; }
    public void setAttendees(int attendees) { this.attendees = attendees; }
}
