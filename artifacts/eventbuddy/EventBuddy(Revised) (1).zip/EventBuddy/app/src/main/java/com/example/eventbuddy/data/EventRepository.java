package com.example.eventbuddy.data;

import android.content.Context;

import java.util.List;


public class EventRepository {

    private final DBHelper dbHelper;

    public EventRepository(Context context) {
        // Use application context to avoid leaking an Activity
        this.dbHelper = new DBHelper(context.getApplicationContext());
    }

    public List<Event> getAllEvents() {
        return dbHelper.getAllEvents();
    }

    public List<Event> searchEventsByTitle(String keyword) {
        if (keyword == null) {
            keyword = "";
        }
        return dbHelper.searchEventsByTitle(keyword);
    }

    public long insertEvent(Event event) {
        if (event == null) {
            throw new IllegalArgumentException("event must not be null");
        }
        return dbHelper.insertEvent(event);
    }

    public int updateEvent(Event event) {
        if (event == null) {
            throw new IllegalArgumentException("event must not be null");
        }
        return dbHelper.updateEvent(event);
    }

    public int deleteEvent(long id) {
        return dbHelper.deleteEvent(id);
    }


    public void insertEvents(List<Event> events) {
        dbHelper.insertEvents(events);
    }
}
