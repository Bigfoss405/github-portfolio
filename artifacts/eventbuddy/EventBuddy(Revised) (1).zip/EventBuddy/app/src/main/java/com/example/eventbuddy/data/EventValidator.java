package com.example.eventbuddy.data;

public class EventValidator {

    public static boolean isValidDate(String dateIso) {
        // Simple check: YYYY-MM-DD length and dashes in correct places
        if (dateIso == null || dateIso.length() != 10) return false;
        if (dateIso.charAt(4) != '-' || dateIso.charAt(7) != '-') return false;

        return true;
    }

    public static boolean isValidTitle(String title) {
        return title != null && title.trim().length() >= 2;
    }

    public static boolean isValidAttendees(String att) {
        if (att == null) return false;
        try {
            return Integer.parseInt(att) >= 0;
        } catch (Exception e) {
            return false;
        }
    }
}

